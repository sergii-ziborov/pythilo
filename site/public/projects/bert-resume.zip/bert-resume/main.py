import json, sys
from finetune_projects.resume import run_project

if __name__ == "__main__":
    print(json.dumps(run_project("artifacts/resume", quick="--quick" in sys.argv), indent=2))
