import json, sys
from finetune_projects.full import run_project

if __name__ == "__main__":
    print(json.dumps(run_project("artifacts/full", quick="--quick" in sys.argv), indent=2))
