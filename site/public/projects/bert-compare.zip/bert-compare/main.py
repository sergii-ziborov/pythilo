import json, sys
from finetune_projects.compare import run_project

if __name__ == "__main__":
    print(json.dumps(run_project("artifacts/compare", quick="--quick" in sys.argv), indent=2))
