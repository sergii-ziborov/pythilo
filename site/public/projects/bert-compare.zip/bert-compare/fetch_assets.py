import runpy, sys
from pathlib import Path
sys.argv = ['fetch_assets.py', '--project-assets', 'assets']
runpy.run_path(str(Path(__file__).parent / 'scripts/fetch-finetune-assets.py'), run_name='__main__')
