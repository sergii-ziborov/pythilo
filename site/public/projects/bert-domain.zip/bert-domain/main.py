import json, sys
from finetune_projects.domain import run_project

if __name__ == "__main__":
    print(json.dumps(run_project("artifacts/domain", quick="--quick" in sys.argv), indent=2))
