# BERT merge project

Install requirements.txt, run `python fetch_assets.py` once, then `python main.py`. The default uses the complete real dataset. `python main.py --quick` explicitly uses a small contract fixture. All code is included; the 17.7 MB pretrained weights and UCI data download separately and are verified by hash. After setup all training and evaluation runs offline on CPU. Outputs are in artifacts/.

Google BERT-Tiny: Apache-2.0, exact revision and hashes in runtime/finetune-assets.json. Kotzias (2015), UCI Sentiment Labelled Sentences, DOI 10.24432/C57604, CC BY 4.0. The downloaded data retains attribution and verbatim source files. Pythilo normalizes and deduplicates in memory.
